package utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

public class Util {
	public static void valiateTheHeaderValuesInResponse(Response response, String statusCode, String message) {
		JsonPath JsonPathEvaluator = response.jsonPath();
		Assert.assertEquals(JsonPathEvaluator.getString("code"), statusCode);
		Assert.assertTrue(JsonPathEvaluator.getString("message").contains(message));

	}

	public static Response getUpdateUserApiResponse(String requestBody, String endpoint, ExtentTest logger) {
		System.out.println("Endpoint: " + endpoint);
		logger.log(LogStatus.INFO, "Endpoint :" + endpoint);
		System.out.println("RequestBody: " + requestBody);
		logger.log(LogStatus.INFO, "RequestBody :" + requestBody);
		return given().header("accept", "application/json").contentType("application/json").body(requestBody).when()
				.put(endpoint).then().extract().response();
	}

	public static Response getLoginUserApiResponse(String endpoint, ExtentTest logger, Map<String, String> data) {
		System.out.println("Endpoint: " + endpoint);
		logger.log(LogStatus.INFO, "Endpoint :" + endpoint);
		return given().header("accept", "application/json").queryParam("username", data.get("USERNAME"))
				.queryParam("password", data.get("PASSWORD")).when().get(endpoint).then().extract().response();
	}

	public static Response getDeleteOrderApiResponse(String endpoint, ExtentTest logger) {
		System.out.println("Endpoint: " + endpoint);
		logger.log(LogStatus.INFO, "Endpoint :" + endpoint);
		return given().header("accept", "application/json").when().delete(endpoint).then().extract().response();
	}

	public static Response getDeletenUserApiResponse(String endpoint, ExtentTest logger) {
		System.out.println("Endpoint: " + endpoint);
		logger.log(LogStatus.INFO, "Endpoint :" + endpoint);
		return given().header("accept", "application/json").when().delete(endpoint).then().extract().response();
	}

	public static Response getLogOutnUserApiResponse(String endpoint, ExtentTest logger) {
		System.out.println("Endpoint: " + endpoint);
		logger.log(LogStatus.INFO, "Endpoint :" + endpoint);
		return given().header("accept", "application/json").when().get(endpoint).then().extract().response();
	}

	public static Response getUserApiResponse(String endpoint, ExtentTest logger) {
		System.out.println("Endpoint: " + endpoint);
		logger.log(LogStatus.INFO, "Endpoint :" + endpoint);
		return given().header("accept", "application/json").when().get(endpoint).then().extract().response();
	}

	public static Response getOrderApiResponse(String endpoint, ExtentTest logger) {
		System.out.println("Endpoint: " + endpoint);
		logger.log(LogStatus.INFO, "Endpoint :" + endpoint);
		return given().header("accept", "application/json").when().get(endpoint).then().extract().response();
	}

	public static String formatDate() {
		Date date = new Date();

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		return format.format(date);
	}

	public static Response getAddUserApiResponse(String requestBody, String endpoint, ExtentTest logger)

	{
		System.out.println("Endpoint: " + endpoint);
		logger.log(LogStatus.INFO, "Endpoint :" + endpoint);
		System.out.println("RequestBody: " + requestBody);
		logger.log(LogStatus.INFO, "RequestBody :" + requestBody);
		return given().header("accept", "application/json").contentType("application/json").body(requestBody).when()
				.post(endpoint).then().extract().response();
	}

	public static Response getPlaceOrderApiResponse(String requestBody, String endpoint, ExtentTest logger) {
		System.out.println("Endpoint: " + endpoint);
		logger.log(LogStatus.INFO, "Endpoint :" + endpoint);
		System.out.println("RequestBody: " + requestBody);
		logger.log(LogStatus.INFO, "RequestBody :" + requestBody);
		return given().header("accept", "application/json").contentType("application/json").body(requestBody).when()
				.post(endpoint).then().extract().response();
	}

	public static String replaceValuesInRequestBody(String requestBodyFilePath, Map<String, String> data) {

		String json = readJsonFileAsString(requestBodyFilePath);
		for (String key : data.keySet()) {
			json = json.replace(key, data.get(key));
		}
		return json;

	}

	public static int getRandomNumberWithinRange(int Min, int Max) {
		return Min + (int) (Math.random() * ((Max - Min) + 1));
	}

	public static String readJsonFileAsString(String file) {
		String jsonString = null;
		try {
			jsonString = new String(Files.readAllBytes(Paths.get(file)));
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		return jsonString;
	}

	public static String getRandomNumber(int digCount) {
		Random random = new Random();
		StringBuilder sb = new StringBuilder(digCount);
		for (int i = 0; i < digCount; i++)
			sb.append((char) ('0' + random.nextInt(10)));
		return sb.toString();
	}

	public static String getRandomString(int n) {
		String AlphaString = "abcdefghijklmnopqrstuvxyz";
		StringBuilder sb = new StringBuilder(n);
		for (int i = 0; i < n; i++) {
			int index = (int) (AlphaString.length() * Math.random());
			sb.append(AlphaString.charAt(index));
		}

		return sb.toString();
	}
}
