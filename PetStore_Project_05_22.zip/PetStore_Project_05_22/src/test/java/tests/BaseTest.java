package tests;

import org.testng.IHookCallBack;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class BaseTest {
	public static ExtentTest logger=null;
	public static ExtentReports report=null;

	@AfterMethod
	public static void endTest() {
		report.endTest(logger);
		
	}
	@AfterSuite
	public void tearDown() {
		report.flush();
	}

	public void initReport(IHookCallBack callBack, ITestResult testResult) {
		logger = report.startTest(testResult.getName());
		callBack.runTestMethod( testResult );

	}
	@BeforeSuite
	public static void startTest() {
		report = new ExtentReports(System.getProperty("user.dir") + "/test-output/ExtentReport/Report.html");
		
	}

}
