package tests;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import org.testng.Assert;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.DataProvider;
import utils.ExcelUtil;
import utils.Util;

public class PetStoreUserDetailsTests extends BaseTest implements IHookable {

	String requestBodyTemplatePath = System.getProperty("user.dir") + "/src/test/resources/AddUserDetails.json";
	public Map<String, String> userData = new HashMap<>();

	@DataProvider(name = "masterDataProvider")
	public Object[][] getdata(Method method) {
		String excelPath = System.getProperty("user.dir") + "/src/test/resources/PetStoreUserDetailsTests.xlsx";
		System.out.println(excelPath);
		LinkedHashMap<String, String> data = ExcelUtil.readValueFromExcelAsMap(excelPath, "Sheet1")
				.get(method.getName());
		System.out.println(data);
		Object[][] value = new Object[][] { { data } };
		return value;
	}

	@Test(priority = 1, dataProvider = "masterDataProvider", enabled = true)
	public void addUserTest(Map<String, String> data) {
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution started");
		String endpoint = System.getenv("EDNP_URL") + data.get("URI");
		createRandomUserDetails(data);
		String requestBody = Util.replaceValuesInRequestBody(requestBodyTemplatePath, data);
		Response response = Util.getAddUserApiResponse(requestBody, endpoint, logger);
		System.out.println(response.asPrettyString());
		logger.log(LogStatus.INFO, "Response :" + response.prettyPrint());
		Util.valiateTheHeaderValuesInResponse(response, "200", data.get("ID"));
		logger.log(LogStatus.INFO, userData.get("USERNAME") + " user created");
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution completed");
		logger.log(LogStatus.PASS, "Test Passed");

	}

	@Test(priority = 2, dataProvider = "masterDataProvider", dependsOnMethods = { "addUserTest" }, enabled = true)
	public void getUserTest(Map<String, String> data) {
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution started");
		String endpoint = System.getenv("EDNP_URL") + data.get("URI") + "/" + userData.get("USERNAME");
		Response response = Util.getUserApiResponse(endpoint, logger);
		System.out.println(response.asPrettyString());
		logger.log(LogStatus.INFO, "Response :" + response.prettyPrint());
		validateGetApiResponse(response, userData);
		logger.log(LogStatus.INFO, userData.get("USERNAME") + " user details retrieved");
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution completed");
		logger.log(LogStatus.PASS, "Test Passed");

	}

	@Test(priority = 3, dataProvider = "masterDataProvider", dependsOnMethods = { "getUserTest" }, enabled = true)
	public void loginUserTest(Map<String, String> data) {
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution started");
		String endpoint = System.getenv("EDNP_URL") + data.get("URI");
		Response response = Util.getLoginUserApiResponse(endpoint, logger, userData);
		System.out.println(response.asPrettyString());
		logger.log(LogStatus.INFO, "Response :" + response.prettyPrint());
		Util.valiateTheHeaderValuesInResponse(response, "200", "logged in user session:");
		logger.log(LogStatus.INFO, userData.get("USERNAME") + " user loggedin");
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution completed");
		logger.log(LogStatus.PASS, "Test Passed");

	}

	@Test(priority = 4, dataProvider = "masterDataProvider", dependsOnMethods = { "loginUserTest" }, enabled = true)
	public void updateUserTest(Map<String, String> data) {
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution started");
		String endpoint = System.getenv("EDNP_URL") + data.get("URI") + "/" + userData.get("USERNAME");
		userData.put("PHONE_NUMBER", Util.getRandomNumber(10));
		String requestBody = Util.replaceValuesInRequestBody(requestBodyTemplatePath, userData);
		Response response = Util.getUpdateUserApiResponse(requestBody, endpoint, logger);
		System.out.println(response.asPrettyString());
		logger.log(LogStatus.INFO, "Response :" + response.prettyPrint());
		Util.valiateTheHeaderValuesInResponse(response, "200", userData.get("ID"));
		// Validate the updated details
		endpoint = System.getenv("EDNP_URL") + data.get("URI") + "/" + userData.get("USERNAME");
		response = Util.getUserApiResponse(endpoint, logger);
		System.out.println(response.asPrettyString());
		logger.log(LogStatus.INFO, "Response :" + response.prettyPrint());
		validateGetApiResponse(response, userData);
		logger.log(LogStatus.INFO, userData.get("USERNAME") + " details updated and validated");
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution completed");
		logger.log(LogStatus.PASS, "Test Passed");

	}

	@Test(priority = 5, dataProvider = "masterDataProvider", dependsOnMethods = { "updateUserTest" }, enabled = true)
	public void logOutUserTest(Map<String, String> data) {
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution started");
		String endpoint = System.getenv("EDNP_URL") + data.get("URI");
		Response response = Util.getLogOutnUserApiResponse(endpoint, logger);
		System.out.println(response.asPrettyString());
		logger.log(LogStatus.INFO, "Response :" + response.prettyPrint());
		Util.valiateTheHeaderValuesInResponse(response, "200", "ok");
		logger.log(LogStatus.INFO, userData.get("USERNAME") + " user loggedout");
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution completed");
		logger.log(LogStatus.PASS, "Test Passed");

	}

	@Test(priority = 6, dataProvider = "masterDataProvider", dependsOnMethods = { "logOutUserTest" }, enabled = true)
	public void deleteUserTest(Map<String, String> data) {
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution started");
		String endpoint = System.getenv("EDNP_URL") + data.get("URI") + "/" + userData.get("USERNAME");
		Response response = Util.getDeletenUserApiResponse(endpoint, logger);
		System.out.println(response.asPrettyString());
		logger.log(LogStatus.INFO, "Response :" + response.prettyPrint());
		Util.valiateTheHeaderValuesInResponse(response, "200", userData.get("USERNAME"));
		logger.log(LogStatus.INFO, userData.get("USERNAME") + " user deleted");
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution completed");
		logger.log(LogStatus.PASS, "Test Passed");

	}

	@Test(priority = 7, dataProvider = "masterDataProvider", enabled = true)
	public void createMultipleUsersWithArray(Map<String, String> data) {
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution started");
		String endpoint = System.getenv("EDNP_URL") + data.get("URI");
		Random random = new Random();
		int n = Util.getRandomNumberWithinRange(1, random.nextInt(10));
		String requestBody = "";
		for (int i = 1; i <= n; i++) {
			createRandomUserDetails(data);
			if (i == n) {
				requestBody = requestBody + Util.replaceValuesInRequestBody(requestBodyTemplatePath, data);
			} else {
				requestBody = requestBody + Util.replaceValuesInRequestBody(requestBodyTemplatePath, data) + ",";
			}

		}
		Response response = Util.getAddUserApiResponse("[" + requestBody + "]", endpoint, logger);
		System.out.println(response.asPrettyString());
		logger.log(LogStatus.INFO, "Response :" + response.prettyPrint());
		Util.valiateTheHeaderValuesInResponse(response, "200", "ok");
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution completed");
		logger.log(LogStatus.PASS, "Test Passed");
	}

	public void validateGetApiResponse(Response response, Map<String, String> data) {
		JsonPath JsonPathEvaluator = response.jsonPath();
		Map<String, Object> responseMap = JsonPathEvaluator.get();
		System.out.println(responseMap);
		Assert.assertEquals(responseMap.get("id").toString(), data.get("ID"));
		Assert.assertEquals(responseMap.get("username").toString(), data.get("USERNAME"));
		Assert.assertEquals(responseMap.get("firstName").toString(), data.get("FIRST_NAME"));
		Assert.assertEquals(responseMap.get("lastName").toString(), data.get("LAST_NAME"));
		Assert.assertEquals(responseMap.get("email").toString(), data.get("EMAIL"));
		Assert.assertEquals(responseMap.get("password").toString(), data.get("PASSWORD"));
		Assert.assertEquals(responseMap.get("phone").toString(), data.get("PHONE_NUMBER"));
		logger.log(LogStatus.INFO, "Response Validation Completed");

	}

	public void createRandomUserDetails(Map<String, String> data) {
		data.put("ID", Util.getRandomNumber(4));
		data.put("USERNAME", Util.getRandomString(5) + Util.getRandomNumber(2));
		data.put("FIRST_NAME", Util.getRandomString(5));
		data.put("LAST_NAME", Util.getRandomString(5));
		data.put("EMAIL", Util.getRandomString(5) + "@gmail.com");
		data.put("PASSWORD", Util.getRandomString(5) + Util.getRandomNumber(2) + "@");
		data.put("PHONE_NUMBER", Util.getRandomNumber(10));
		userData.putAll(data);
	}

	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		initReport(callBack, testResult);

	}

}
