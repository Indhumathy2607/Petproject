package tests;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import org.testng.Assert;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.DataProvider;
import utils.ExcelUtil;
import utils.Util;

public class PetStoreTests extends BaseTest implements IHookable {

	String requestBodyTemplatePath = System.getProperty("user.dir") + "/src/test/resources/PlaceOrder.json";
	public Map<String, String> orderData = new HashMap<>();

	@DataProvider(name = "masterDataProvider")
	public Object[][] getdata(Method method) {
		String excelPath = System.getProperty("user.dir") + "/src/test/resources/PetStoreTests.xlsx";
		System.out.println(excelPath);
		LinkedHashMap<String, String> data = ExcelUtil.readValueFromExcelAsMap(excelPath, "Sheet1")
				.get(method.getName());
		System.out.println(data);
		Object[][] value = new Object[][] { { data } };
		return value;
	}

	@Test(priority = 1, dataProvider = "masterDataProvider", enabled = true)
	public void placeOrderTest(Map<String, String> data) {
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution started");
		String endpoint = System.getenv("EDNP_URL") + data.get("URI");
		createRandomOrderDetails(data);
		String requestBody = Util.replaceValuesInRequestBody(requestBodyTemplatePath, data);
		Response response = Util.getPlaceOrderApiResponse(requestBody, endpoint, logger);
		System.out.println(response.asPrettyString());
		logger.log(LogStatus.INFO, "Response :" + response.prettyPrint());
		validatePlaceOrderApiResponse(response, data);
		logger.log(LogStatus.INFO, orderData.get("ID") + " order placed");
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution completed");
		logger.log(LogStatus.PASS, "Test Passed");

	}
	@Test(priority = 2, dataProvider = "masterDataProvider", dependsOnMethods = { "placeOrderTest" }, enabled = true)
	public void getOrderTest(Map<String, String> data) {
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution started");
		String endpoint = System.getenv("EDNP_URL") + data.get("URI") + "/" + orderData.get("ID");
		Response response = Util.getUserApiResponse(endpoint, logger);
		System.out.println(response.asPrettyString());
		logger.log(LogStatus.INFO, "Response :" + response.prettyPrint());
		validatePlaceOrderApiResponse(response, orderData);
		logger.log(LogStatus.INFO, orderData.get("ID") + " order details retrieved");
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution completed");
		logger.log(LogStatus.PASS, "Test Passed");

	}

	@Test(priority = 3, dataProvider = "masterDataProvider", dependsOnMethods = { "placeOrderTest" }, enabled = true)
	public void deleteOrderTest(Map<String, String> data) {
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution started");
		String endpoint = System.getenv("EDNP_URL") + data.get("URI") + orderData.get("ID");
		Response response = Util.getDeleteOrderApiResponse(endpoint, logger);
		System.out.println(response.asPrettyString());
		logger.log(LogStatus.INFO, "Response :" + response.prettyPrint());
		Util.valiateTheHeaderValuesInResponse(response, "200", orderData.get("ID"));
		logger.log(LogStatus.INFO, orderData.get("ID") + " order deleted");
		logger.log(LogStatus.INFO, data.get("TestMethod") + " test execution completed");
		logger.log(LogStatus.PASS, "Test Passed");

	}
	public void validatePlaceOrderApiResponse(Response response, Map<String, String> data) {
		JsonPath JsonPathEvaluator = response.jsonPath();
		Map<String, Object> responseMap = JsonPathEvaluator.get();
		System.out.println(responseMap);
		Assert.assertEquals(responseMap.get("id").toString(), data.get("ID"));
		Assert.assertEquals(responseMap.get("petId").toString(), data.get("PET"));
		Assert.assertEquals(responseMap.get("quantity").toString(), data.get("QUANTITY"));
		Assert.assertEquals(responseMap.get("shipDate").toString().substring(0,10), data.get("DATE").substring(0,10));
		Assert.assertEquals(responseMap.get("status").toString(), "placed");
		Assert.assertEquals(responseMap.get("complete").toString(), "true");

		logger.log(LogStatus.INFO, "Response Validation Completed");

	}

	public void createRandomOrderDetails(Map<String, String> data) {
		data.put("ID", Util.getRandomNumber(4));
		data.put("PET", Util.getRandomNumber(4));
		data.put("QUANTITY", String.valueOf(Util.getRandomNumberWithinRange(1, 10)));
		data.put("DATE", Util.formatDate());
		orderData.putAll(data);
	}

	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		initReport(callBack, testResult);

	}

}
